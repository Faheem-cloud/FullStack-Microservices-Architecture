const express = require("express");
const app = express();
let products = [
    { id: 1, name: "Laptop" },
    { id: 2, name: "Phone" }
];
// API
app.get("/products", (req, res) => {
    res.json(products);
});
app.listen(3001, () => {
    console.log("Product Service → http://localhost:3001/products");
});
const express = require("express");
const axios = require("axios");
const app = express();
app.use(express.json());
let orders = [];
app.post("/orders", async (req, res) => {
    try {
        const response = await axios.get("http://localhost:3001/products");
        const products = response.data;
        const order = {
            id: Date.now(),
            products: products
        };
        orders.push(order);
        res.json({
            message: "Order created successfully",
            order: order
        });
    } catch (error) {
        res.status(500).json({
            error: "Failed to fetch products from Product Service"
        });
    }
});
app.get("/orders", (req, res) => {
    res.json(orders);
});
app.listen(3002, () => {
    console.log("Order Service → http://localhost:3002/orders");
});
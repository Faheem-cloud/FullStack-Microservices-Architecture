const express = require("express")
const cors = require("cors")
const path = require("path")
const db = require("./db")
const app = express()
app.use(cors())
app.use(express.json())
// Serve static files (HTML, CSS, JS)
app.use(express.static(__dirname))
// Redirect root link to index.html
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"))
})
// Insert student data
app.post("/addStudent", (req, res) => {
const {name,email,dob,department,phone} = req.body
const sql = "INSERT INTO students(name,email,dob,department,phone) VALUES (?,?,?,?,?)"
db.query(sql,[name,email,dob,department,phone],(err,result)=>{
if(err){
res.send(err)
}else{
res.send("Student Added Successfully")
}
})

})
// Get student data
app.get("/students",(req,res)=>{
db.query("SELECT * FROM students",(err,result)=>{
if(err){
res.send(err)
}else{
res.json(result)
}
})

})
// Start server
app.listen(3000,()=>{
console.log("Server running at: http://localhost:3000")
})
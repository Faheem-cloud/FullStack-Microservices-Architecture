const mysql = require("mysql")
const db = mysql.createConnection({
host: "localhost",
user: "root",
password: "fahi",
database: "studentdb"
})
db.connect((err)=>{
if(err){
console.log("Database Error:", err)
}else{
console.log("MySQL Connected Successfully")
}
})
module.exports = db
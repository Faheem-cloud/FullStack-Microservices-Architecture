const form = document.getElementById("studentForm")
form.addEventListener("submit", async (e) => {
e.preventDefault()
const student = {
name: document.getElementById("name").value,
email: document.getElementById("email").value,
dob: document.getElementById("dob").value,
department: document.getElementById("department").value,
phone: document.getElementById("phone").value
}
try{
const res = await fetch("http://localhost:3000/addStudent",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify(student)
})
const data = await res.text()
alert(data)
// clear form
form.reset()
}catch(error){
console.log("Error:",error)
}
})
function goHome(){
window.location.href="index.html"
}
let feedbacks = [];
function saveFeedback(data) {
    feedbacks.push(data);
    console.log("Saved:", data);
}
module.exports = {
    saveFeedback
};
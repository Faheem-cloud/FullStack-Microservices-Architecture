const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const db = require("./db");
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(__dirname));
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"));
});
app.post("/submit", (req, res) => {
    const { name, email, message } = req.body;
    db.saveFeedback({ name, email, message });
    res.json({ status: "success" });
});
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
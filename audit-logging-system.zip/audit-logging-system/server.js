const express = require('express');
const cors = require('cors');
const db = require('./db');
const app = express();
// Middleware
app.use(cors());
app.use(express.json());
// ✅ FIXED: Serve current folder
app.use(express.static(__dirname));
// ---------------- ROUTES ---------------- //
// Add Employee
app.post('/add', (req, res) => {
    const { emp_id, name, salary } = req.body;
    const sql = "INSERT INTO employees VALUES (?, ?, ?, NOW())";
    db.query(sql, [emp_id, name, salary], (err, result) => {
        if (err) {
            console.error(err);
            return res.send("Error adding employee");
        }
        res.send("Employee Added");
    });
});
// Update Employee
app.put('/update/:id', (req, res) => {
    const { salary } = req.body;
    const id = req.params.id;
    const sql = "UPDATE employees SET salary=? WHERE emp_id=?";
    db.query(sql, [salary, id], (err, result) => {
        if (err) {
            console.error(err);
            return res.send("Error updating employee");
        }
        res.send("Employee Updated");
    });
});
// Get Logs
app.get('/logs', (req, res) => {
    db.query("SELECT * FROM employee_log", (err, result) => {
        if (err) {
            console.error(err);
            return res.send("Error fetching logs");
        }
        res.json(result);
    });
});
// Get Daily Report (View)
app.get('/report', (req, res) => {
    db.query("SELECT * FROM daily_activity_report", (err, result) => {
        if (err) {
            console.error(err);
            return res.send("Error fetching report");
        }
        res.json(result);
    });
});
// ---------------- SERVER ---------------- //
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
let students = [];
function add(s) {
    students.push(s);
}
function getAll() {
    return students;
}
module.exports = { add, getAll };
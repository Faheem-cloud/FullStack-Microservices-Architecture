function addStudent() {
    const data = {
        name: val("name"),
        age: val("age"),
        dept: val("dept")
    };
    fetch("/add", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(data)
    }).then(loadStudents);
}
function loadStudents() {
    const dept = val("filterDept");
    const sort = val("sortBy");
    const page = val("page");

    fetch(`/students?dept=${dept}&sort=${sort}&page=${page}`)
    .then(res => res.json())
    .then(data => {
        let list = document.getElementById("list");
        list.innerHTML = "";

        data.forEach(s => {
            let li = document.createElement("li");
            li.innerText = `${s.name} (${s.age}) - ${s.dept}`;
            list.appendChild(li);
        });
    });
}
function val(id){
    return document.getElementById(id).value;
}

loadStudents();
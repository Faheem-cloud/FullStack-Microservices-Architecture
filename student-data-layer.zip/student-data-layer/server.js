const express = require("express");
const cors = require("cors");
const db = require("./db");
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));
// Add student
app.post("/add", (req, res) => {
    db.add(req.body);
    res.json({msg:"Added"});
});
// Filter + Sort + Pagination
app.get("/students", (req, res) => {
    let { dept, sort, page } = req.query;
    let data = db.getAll();
    // FILTER
    if (dept) {
        data = data.filter(s => s.dept === dept);
    }
    // SORT
    if (sort === "name") {
        data.sort((a,b)=>a.name.localeCompare(b.name));
    } else if (sort === "age") {
        data.sort((a,b)=>a.age - b.age);
    }
    // PAGINATION
    let limit = 3;
    page = parseInt(page) || 1;
    let start = (page - 1) * limit;
    let paginated = data.slice(start, start + limit);

    res.json(paginated);
});

app.listen(3000, () => console.log("http://localhost:3000"));
async function loadStudents(){

const res = await fetch("http://localhost:3000/students")
let students = await res.json()

const sortValue = document.getElementById("sortSelect").value
const filterDept = document.getElementById("departmentFilter").value

// FILTER
if(filterDept){
students = students.filter(s => s.department === filterDept)
}

// SORT
if(sortValue === "name"){
students.sort((a,b)=>a.name.localeCompare(b.name))
}

if(sortValue === "dob"){
students.sort((a,b)=> new Date(a.dob) - new Date(b.dob))
}

// DISPLAY TABLE
let html = ""

students.forEach(s=>{
html += `
<tr>
<td>${s.id}</td>
<td>${s.name}</td>
<td>${s.email}</td>
<td>${s.dob}</td>
<td>${s.department}</td>
<td>${s.phone}</td>
</tr>
`
})

document.getElementById("studentTable").innerHTML = html

// COUNT PER DEPARTMENT
let counts = {}

students.forEach(s=>{
counts[s.department] = (counts[s.department] || 0) + 1
})

let countHTML = ""

for(let dept in counts){
countHTML += `<p>${dept} : ${counts[dept]} Students</p>`
}

document.getElementById("deptCount").innerHTML = countHTML

}

loadStudents()
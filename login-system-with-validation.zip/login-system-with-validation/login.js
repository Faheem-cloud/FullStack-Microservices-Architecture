const form = document.getElementById("loginForm")
form.addEventListener("submit", async (e)=>{
e.preventDefault()
const username = document.getElementById("username").value
const password = document.getElementById("password").value
const errorMsg = document.getElementById("errorMsg")
// validation
if(username === "" || password === ""){
errorMsg.innerText = "All fields are required"
return
}
try{
const res = await fetch("http://localhost:3000/login",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({username,password})
})
const data = await res.text()
if(data === "success"){
window.location.href = "index.html"
}else{
errorMsg.innerText = "Invalid username or password"
}
}catch(error){
console.log(error)
}
})
const express = require("express")
const cors = require("cors")
const path = require("path")
const db = require("./db")
const app = express()
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
// Disable default index.html loading
app.use(express.static(__dirname, { index: false }))
// ==========================
// OPEN LOGIN PAGE FIRST
// ==========================
app.get("/", (req, res) => {
res.sendFile(path.join(__dirname, "login.html"))
})
// ==========================
// LOGIN SYSTEM
// ==========================
app.post("/login",(req,res)=>{
const {username,password} = req.body
const sql = "SELECT * FROM users WHERE username=? AND password=?"
db.query(sql,[username,password],(err,result)=>{
if(err){
res.send("error")
return
}
if(result.length > 0){
res.send("success")
}else{
res.send("fail")
}
})
})
// ==========================
// STUDENT REGISTRATION
// ==========================
app.post("/addStudent",(req,res)=>{
const {name,email,dob,department,phone} = req.body
const sql = "INSERT INTO students(name,email,dob,department,phone) VALUES (?,?,?,?,?)"
db.query(sql,[name,email,dob,department,phone],(err,result)=>{
if(err){
res.send(err)
}else{
res.send("Student Added Successfully")
}

})

})
// ==========================
// GET STUDENTS (Dashboard)
// ==========================

app.get("/students",(req,res)=>{

db.query("SELECT * FROM students",(err,result)=>{

if(err){
res.send(err)
}else{
res.json(result)
}

})

})
// ==========================
// START SERVER
// ==========================
app.listen(3000,()=>{
console.log("Server running at: http://localhost:3000")
})
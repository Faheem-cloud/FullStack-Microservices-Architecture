let students = [];
function add(s) {
    students.push(s);
}
function getAll() {
    return students;
}
function update(updated) {
    students = students.map(s =>
        s.id == updated.id ? updated : s
    );
}
function remove(id) {
    students = students.filter(s => s.id != id);
}
module.exports = { add, getAll, update, remove };
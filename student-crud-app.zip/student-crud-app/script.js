function addStudent() {
    let data = getInput();
    fetch("/add", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(data)
    }).then(loadStudents);
}
function loadStudents() {
    fetch("/all")
    .then(res => res.json())
    .then(data => {
        let list = document.getElementById("list");
        list.innerHTML = "";
        data.forEach(s => {
            let li = document.createElement("li");
            li.innerHTML = `
                ${s.id} - ${s.name} (${s.course})
                <button onclick="deleteStudent(${s.id})">❌</button>
            `;
            list.appendChild(li);
        });
    });
}
function updateStudent() {
    let data = getInput();
    fetch("/update", {
        method: "PUT",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(data)
    }).then(loadStudents);
}
function deleteStudent(id) {
    fetch(`/delete/${id}`, { method: "DELETE" })
    .then(loadStudents);
}
function getInput() {
    return {
        id: document.getElementById("id").value,
        name: document.getElementById("name").value,
        course: document.getElementById("course").value
    };
}

loadStudents();
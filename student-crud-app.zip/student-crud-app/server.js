const express = require("express");
const cors = require("cors");
const db = require("./db");
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));
// CREATE
app.post("/add", (req, res) => {
    db.add(req.body);
    res.json({msg:"Added"});
});
// READ
app.get("/all", (req, res) => {
    res.json(db.getAll());
});
// UPDATE
app.put("/update", (req, res) => {
    db.update(req.body);
    res.json({msg:"Updated"});
});
// DELETE
app.delete("/delete/:id", (req, res) => {
    db.remove(req.params.id);
    res.json({msg:"Deleted"});
});
app.listen(3000, () => console.log("http://localhost:3000"));
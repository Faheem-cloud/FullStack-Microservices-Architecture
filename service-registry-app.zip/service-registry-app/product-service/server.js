const express = require("express");
const axios = require("axios");

const app = express();
app.use(express.json());

let products = [];

// Register with registry
axios.post("http://localhost:4000/register", {
    name: "product-service",
    url: "http://localhost:3001"
}).catch(()=>{});

// APIs
app.get("/products", (req, res) => {
    res.json(products);
});

app.post("/products", (req, res) => {
    products.push(req.body);
    res.json({ msg: "Product added" });
});

app.listen(3001, () => {
    console.log("Product Service running at 3001");
});
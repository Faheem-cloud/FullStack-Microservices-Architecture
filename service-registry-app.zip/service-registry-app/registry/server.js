const express = require("express");
const app = express();

app.use(express.json());

let services = {};

// Register service
app.post("/register", (req, res) => {
    const { name, url } = req.body;
    services[name] = url;
    console.log(`${name} registered at ${url}`);
    res.json({ msg: "Registered" });
});

// Get service URL
app.get("/service/:name", (req, res) => {
    const service = services[req.params.name];
    if (!service) {
        return res.status(404).json({ error: "Service not found" });
    }
    res.json({ url: service });
});

app.listen(4000, () => {
    console.log("Registry running at http://localhost:4000");
});
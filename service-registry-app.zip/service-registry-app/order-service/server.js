const express = require("express");
const axios = require("axios");

const app = express();
app.use(express.json());

let orders = [];

// Register with registry
axios.post("http://localhost:4000/register", {
    name: "order-service",
    url: "http://localhost:3002"
}).catch(()=>{});

// Create order (calls product-service dynamically)
app.post("/orders", async (req, res) => {
    try {
        // Discover product service
        const response = await axios.get("http://localhost:4000/service/product-service");
        const productURL = response.data.url;

        // Call product service
        const products = await axios.get(productURL + "/products");

        orders.push({
            order: req.body,
            products: products.data
        });

        res.json({ msg: "Order created", orders });

    } catch (err) {
        res.status(500).json({ error: "Service discovery failed" });
    }
});

app.get("/orders", (req, res) => {
    res.json(orders);
});

app.listen(3002, () => {
    console.log("Order Service running at 3002");
});
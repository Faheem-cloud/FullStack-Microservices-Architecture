let employees = [];
function addEmployee(emp) {
    employees.push(emp);
}
function getEmployees() {
    return employees;
}
module.exports = { addEmployee, getEmployees };
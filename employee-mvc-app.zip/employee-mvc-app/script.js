function addEmployee() {
    const name = document.getElementById("name").value;
    const role = document.getElementById("role").value;
    fetch("/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, role })
    })
    .then(() => loadEmployees());
}
function loadEmployees() {
    fetch("/all")
    .then(res => res.json())
    .then(data => {
        let list = document.getElementById("list");
        list.innerHTML = "";
        data.forEach(emp => {
            let li = document.createElement("li");
            li.innerText = emp.name + " - " + emp.role;
            list.appendChild(li);
        });
    });
}
loadEmployees();
const express = require("express");
const cors = require("cors");
const path = require("path");
const db = require("./db");
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));
app.post("/add", (req, res) => {
    db.addEmployee(req.body);
    res.json({ msg: "Employee Added" });
});
app.get("/all", (req, res) => {
    res.json(db.getEmployees());
});
app.listen(3000, () => {
    console.log("http://localhost:3000");
});
const request = require("supertest");
const app = require("../product-service/app");
describe("Product API Tests", () => {
    test("GET /products should return empty array", async () => {
        const res = await request(app).get("/products");
        expect(res.statusCode).toBe(200);
        expect(res.body).toEqual([]);
    });
    test("POST /products should add product", async () => {
        const res = await request(app)
            .post("/products")
            .send({ name: "Laptop" });
        expect(res.statusCode).toBe(200);
        expect(res.body.msg).toBe("Product added");
    });
    test("GET /products should return data", async () => {
        const res = await request(app).get("/products");
        expect(res.body.length).toBeGreaterThan(0);
    });

});
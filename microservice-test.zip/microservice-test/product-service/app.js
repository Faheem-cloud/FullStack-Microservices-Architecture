const express = require("express");
const app = express();
app.use(express.json());
let products = [];
// API
app.get("/products", (req, res) => {
    res.json(products);
});
app.post("/products", (req, res) => {
    products.push(req.body);
    res.json({ msg: "Product added" });
});
module.exports = app;
let usersData = []
let merchantsData = []
function loadData(){
fetch("/balances")
.then(res=>res.json())
.then(data=>{
usersData = data.users
merchantsData = data.merchants
let userSelect = document.getElementById("user")
let merchantSelect = document.getElementById("merchant")
userSelect.innerHTML=""
merchantSelect.innerHTML=""
// fill users
usersData.forEach(u=>{
userSelect.innerHTML += `<option value="${u.id}">${u.name}</option>`
})
window.onload = loadData
// fill merchants
merchantsData.forEach(m=>{
merchantSelect.innerHTML += `<option value="${m.id}">${m.name}</option>`
})
// show initial balances
updateBalances()
})
}
function updateBalances(){
let userId = document.getElementById("user").value
let merchantId = document.getElementById("merchant").value
let user = usersData.find(u=>u.id == userId)
let merchant = merchantsData.find(m=>m.id == merchantId)
document.getElementById("userBalance").innerText =
"User Balance: ₹" + user.balance
document.getElementById("merchantBalance").innerText =
"Shop Balance: ₹" + merchant.balance
}
function pay(){
let userId = document.getElementById("user").value
let merchantId = document.getElementById("merchant").value
let amount = document.getElementById("amount").value
fetch("/pay",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
userId:userId,
merchantId:merchantId,
amount:amount
})
})
.then(res=>res.json())
.then(data=>{
document.getElementById("result").innerText = data.message
loadData()
})
}
window.onload = loadData
const express = require("express")
const db = require("./db")
const app = express()
app.use(express.json())
app.use(express.static(__dirname))
app.get("/", (req, res) => {
    res.sendFile(__dirname + "/index.html")
})
app.post("/pay", (req, res) => {
    const { userId, merchantId, amount } = req.body
    const amt = parseInt(amount)
    if (!amt || amt <= 0) {
        return res.json({ message: "Enter valid amount" })
    }
    db.beginTransaction(err => {
        if (err) return res.status(500).send("Transaction error")
        // 1. Get user balance
        db.query("SELECT balance FROM users WHERE id=?", [userId], (err, result) => {
            if (err || result.length === 0) {
                return db.rollback(() => res.send("User not found"))
            }
            let balance = result[0].balance
            if (balance < amt) {
                return db.rollback(() => {
                    res.json({ message: "Insufficient Balance" })
                })
            }

            // 2. Deduct from user
            db.query(
                "UPDATE users SET balance = balance - ? WHERE id=?",
                [amt, userId],
                (err) => {

                    if (err) {
                        return db.rollback(() => res.send("Deduction failed"))
                    }

                    // 3. Add to merchant
                    db.query(
                        "UPDATE merchants SET balance = balance + ? WHERE id=?",
                        [amt, merchantId],
                        (err) => {

                            if (err) {
                                return db.rollback(() => res.send("Merchant update failed"))
                            }
                            // 4. Commit
                            db.commit(err => {

                                if (err) {
                                    return db.rollback(() => res.send("Commit failed"))
                                }

                                res.json({ message: "Payment Successful ✅" })
                            })
                        }
                    )
                }
            )
        })
    })
})
app.get("/balances", (req, res) => {

    db.query("SELECT * FROM users", (err, users) => {

        if (err) return res.send("Error fetching users")

        db.query("SELECT * FROM merchants", (err, merchants) => {

            if (err) return res.send("Error fetching merchants")

            res.json({
                users: users,
                merchants: merchants
            })
        })
    })
})
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000")
})
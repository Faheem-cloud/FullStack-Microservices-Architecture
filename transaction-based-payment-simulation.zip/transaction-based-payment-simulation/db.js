const mysql = require("mysql")
const db = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"fahi",
    database:"payment_simulation"
})

db.connect((err)=>{
    if(err) throw err
    console.log("MySQL Connected")
})

module.exports = db
const express = require("express");
const cors = require("cors");
const db = require("./db");
const app = express();
app.use(cors());
app.use(express.json());
/* ---------------- VALIDATION MIDDLEWARE ---------------- */
function validateProduct(req, res, next) {
    const { id, name, price } = req.body;

    if (!id || !name || !price) {
        return next({ status: 400, message: "All fields are required" });
    }

    if (isNaN(price)) {
        return next({ status: 400, message: "Price must be a number" });
    }

    next();
}

/* ---------------- CRUD APIs ---------------- */

// GET
app.get("/products", (req, res) => {
    res.json(db.getAll());
});
// POST
app.post("/products", validateProduct, (req, res) => {
    db.add(req.body);
    res.json({ message: "Product added successfully" });
});
// PUT
app.put("/products/:id", validateProduct, (req, res, next) => {
    const updated = db.update(req.params.id, req.body);
    if (!updated) {
        return next({ status: 404, message: "Product not found" });
    }

    res.json({ message: "Product updated successfully" });
});
// DELETE
app.delete("/products/:id", (req, res, next) => {
    const deleted = db.remove(req.params.id);
    if (!deleted) {
        return next({ status: 404, message: "Product not found" });
    }
    res.json({ message: "Product deleted successfully" });
});
/* ---------------- GLOBAL ERROR HANDLER ---------------- */
app.use((err, req, res, next) => {
    res.status(err.status || 500).json({
        error: err.message || "Internal Server Error"
    });
});
app.listen(3000, () => {
    console.log("🚀 http://localhost:3000/products");
});
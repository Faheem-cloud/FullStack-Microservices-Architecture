function add() {
    fetch("/products", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(getData())
    }).then(get);
}
function get() {
    fetch("/products")
    .then(res => res.json())
    .then(data => {
        let list = document.getElementById("list");
        list.innerHTML = "";
        data.forEach(p => {
            let li = document.createElement("li");
            li.innerText = `${p.id} - ${p.name} - ₹${p.price}`;
            list.appendChild(li);
        });
    });
}
function getData() {
    return {
        id: document.getElementById("id").value,
        name: document.getElementById("name").value,
        price: document.getElementById("price").value
    };
}
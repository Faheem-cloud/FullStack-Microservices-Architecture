let products = [];
function getAll() {
    return products;
}
function add(p) {
    products.push(p);
}
function update(id, newData) {
    let found = false;
    products = products.map(p => {
        if (p.id == id) {
            found = true;
            return { ...p, ...newData };
        }
        return p;
    });

    return found;
}
function remove(id) {
    const initialLength = products.length;
    products = products.filter(p => p.id != id);
    return products.length !== initialLength;
}
module.exports = { getAll, add, update, remove };
const express = require("express");
const cors = require("cors");
const path = require("path");
const db = require("./db");
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"));
});
app.post("/add", (req, res) => {
    db.addEmployee(req.body);
    res.json({ msg: "Added" });
});
app.get("/all", (req, res) => {
    res.json(db.getEmployees());
});
app.listen(3000, () => {
    console.log("🚀 Server running at: http://localhost:3000");
});
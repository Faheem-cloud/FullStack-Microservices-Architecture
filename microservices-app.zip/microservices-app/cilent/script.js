function addProduct() {
    fetch("http://localhost:3001/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: val("pname") })
    });
}
function addOrder() {
    fetch("http://localhost:3002/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ item: val("order") })
    });
}
function val(id) {
    return document.getElementById(id).value;
}
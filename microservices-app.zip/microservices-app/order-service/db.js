let orders = [];
function add(o) {
    orders.push(o);
}
function getAll() {
    return orders;
}
module.exports = { add, getAll };
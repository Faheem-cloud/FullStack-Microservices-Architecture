const express = require("express");
const cors = require("cors");
const db = require("./db");
const app = express();
app.use(cors());
app.use(express.json());
// GET orders
app.get("/orders", (req, res) => {
    res.json(db.getAll());
});
// ADD order
app.post("/orders", (req, res) => {
    db.add(req.body);
    res.json({ msg: "Order placed" });
});
app.listen(3002, () => {
    console.log("Order Service running at http://localhost:3002");
});
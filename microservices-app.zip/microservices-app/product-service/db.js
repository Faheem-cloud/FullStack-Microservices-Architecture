let products = [];
function add(p) {
    products.push(p);
}
function getAll() {
    return products;
}
module.exports = { add, getAll };
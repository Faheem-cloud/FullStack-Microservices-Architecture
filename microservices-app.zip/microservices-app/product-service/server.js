const express = require("express");
const cors = require("cors");
const db = require("./db");
const app = express();
app.use(cors());
app.use(express.json());
// GET products
app.get("/products", (req, res) => {
    res.json(db.getAll());
});
// ADD product
app.post("/products", (req, res) => {
    db.add(req.body);
    res.json({ msg: "Product added" });
});
app.listen(3001, () => {
    console.log("Product Service running at http://localhost:3001");
});
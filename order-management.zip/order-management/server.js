const express=require("express")
const db=require("./db")

const app=express()

app.use(express.json())
app.use(express.static(__dirname))

// LOGIN

app.post("/login",(req,res)=>{

const {username,password}=req.body

const sql="SELECT * FROM users WHERE username=? AND password=?"

db.query(sql,[username,password],(err,result)=>{

if(err) throw err

if(result.length>0){
res.json({success:true})
}else{
res.json({success:false})
}

})

})



// ADD CUSTOMER

app.post("/add-customer",(req,res)=>{

const {name,email}=req.body

const sql="INSERT INTO customers(name,email) VALUES(?,?)"

db.query(sql,[name,email],(err)=>{

if(err) throw err

res.send("Customer Added Successfully")

})

})



// ADD PRODUCT

app.post("/add-product",(req,res)=>{

const {product,price}=req.body

const sql="INSERT INTO products(product_name,price) VALUES(?,?)"

db.query(sql,[product,price],(err)=>{

if(err) throw err

res.send("Product Added Successfully")

})

})



// GET CUSTOMERS (for dropdown)

app.get("/customers",(req,res)=>{

const sql="SELECT * FROM customers"

db.query(sql,(err,result)=>{

if(err) throw err

res.json(result)

})

})

// GET PRODUCTS (for dropdown)

app.get("/products",(req,res)=>{

const sql="SELECT * FROM products"

db.query(sql,(err,result)=>{

if(err) throw err

res.json(result)

})

})

// PLACE ORDER

app.post("/place-order",(req,res)=>{

const {customer_id,product_id,quantity}=req.body

const sql="INSERT INTO orders(customer_id,product_id,quantity) VALUES(?,?,?)"

db.query(sql,[customer_id,product_id,quantity],(err)=>{

if(err) throw err

res.send("Order Placed Successfully")

})

})
// ORDER HISTORY (JOIN)

app.get("/orders",(req,res)=>{

const sql=`

SELECT customers.name,
products.product_name,
products.price,
orders.quantity,
(products.price * orders.quantity) AS total

FROM orders

JOIN customers
ON orders.customer_id = customers.id

JOIN products
ON orders.product_id = products.id

ORDER BY orders.order_date DESC

`
db.query(sql,(err,result)=>{

if(err) throw err

res.json(result)

})

})

// HIGHEST VALUE ORDER (SUBQUERY)

app.get("/highest-order",(req,res)=>{

const sql=`

SELECT customers.name,
(products.price * orders.quantity) AS total

FROM orders

JOIN customers
ON orders.customer_id = customers.id

JOIN products
ON orders.product_id = products.id

WHERE (products.price * orders.quantity) =

(
SELECT MAX(products.price * orders.quantity)
FROM orders
JOIN products
ON orders.product_id = products.id
)

`

db.query(sql,(err,result)=>{

if(err) throw err

res.json(result)

})

})



// MOST ACTIVE CUSTOMER

app.get("/active-customer",(req,res)=>{

const sql=`

SELECT customers.name,
COUNT(orders.id) AS total_orders

FROM customers

JOIN orders
ON customers.id = orders.customer_id

GROUP BY customers.id

ORDER BY total_orders DESC

LIMIT 1

`

db.query(sql,(err,result)=>{

if(err) throw err

res.json(result)

})

})



// START SERVER

app.listen(3000,()=>{

console.log("Server running at http://localhost:3000")

})
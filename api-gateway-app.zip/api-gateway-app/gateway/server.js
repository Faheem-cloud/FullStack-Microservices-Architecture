const express = require("express");
const axios = require("axios");
const app = express();
const services = [
    "http://localhost:3001",
    "http://localhost:3002"
];
let index = 0;
app.get("/products", async (req, res) => {
    try {
        const service = services[index];
        index = (index + 1) % services.length;
        const response = await axios.get(service + "/products");
        res.json(response.data);

    } catch (err) {
        res.status(500).json({ error: "Service unavailable" });
    }
});
app.listen(5000, () => {
    console.log("API Gateway → http://localhost:5000/products");
});
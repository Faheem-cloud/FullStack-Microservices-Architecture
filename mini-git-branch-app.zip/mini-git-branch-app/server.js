const express = require("express");
const db = require("./db");
const app = express();
app.use(express.json());
app.use(express.static(__dirname));
// Create branch
app.post("/branch", (req, res) => {
    db.createBranch(req.body.name);
    res.json({ msg: "Branch created" });
});
// Commit
app.post("/commit", (req, res) => {
    db.commit(req.body.message);
    res.json({ msg: "Committed" });
});
// Merge
app.post("/merge", (req, res) => {
    const result = db.merge();
    res.json({ msg: result });
});
// Rebase
app.post("/rebase", (req, res) => {
    db.rebase();
    res.json({ msg: "Rebased" });
});
// Get data
app.get("/data", (req, res) => {
    res.json(db.getData());
});
app.listen(3000, () => console.log("http://localhost:3000"));
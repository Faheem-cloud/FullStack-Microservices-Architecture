let branches = ["main"];
let current = "main";
let commits = {
    main: []
};
function createBranch(name) {
    branches.push(name);
    commits[name] = [...commits[current]];
}
function commit(msg) {
    commits[current].push(msg);
}
function merge() {
    let mainCommits = commits["main"];
    let featureCommits = commits[current];
    if (mainCommits.length && featureCommits.length) {
        return "Merge Conflict Detected!";
    }
    commits["main"] = [...mainCommits, ...featureCommits];
    return "Merged Successfully";
}
function rebase() {
    commits[current] = [...commits["main"], ...commits[current]];
}
function getData() {
    return {
        branches,
        history: commits[current]
    };
}
module.exports = { createBranch, commit, merge, rebase, getData };